package br.com.alura.bytebank.model;

public enum Tipo {
    DEBITO, CREDITO, DINHEIRO
}
