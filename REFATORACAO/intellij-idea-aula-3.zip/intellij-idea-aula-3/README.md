# Gerenciador de pagamento Byte Bank

Projeto para realizar pagamento da Byte Bank

## Como usar

Para processar os pagamentos, basta apenas incluir o arquivo csv no diretório **recursos** com as informações necessárias e executar o método main da classe `Principal`. Então, vai aparecer no console o arquivo, basta apenas digitar o código do arquivo, isto é, o número que vai aparecer do lado.

## Resultados apresentados

Após execução, aparecerá todos os pagamentos que foram registrados. Também, automaticamente, será criado um diretório chamado **backup** ao qual conterá os arquivos que foram lidos a cada execução.

## Suporte

Para quaisquer dúvidas ou detalhes, consulte a equipe de desenvolvimento.