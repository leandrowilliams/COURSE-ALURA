package br.com.alura.bytebank;

import br.com.alura.bytebank.visualizador.OpcoesPagamento;

public class Principal {
    public static void main(String[] args) {
        new OpcoesPagamento().mensagemDeBoasVindas();
    }

}
